# ISILDUR segementation > 2024-04-24 11:48am
https://universe.roboflow.com/sky-nskuy/isildur-segementation

Provided by a Roboflow user
License: CC BY 4.0

